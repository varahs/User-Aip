// MODULE
var DBVersionTracker = angular.module('DBVersionTracker', ['ngRoute']);

// ROUTES
DBVersionTracker.config(function ($routeProvider) {
   
    $routeProvider
    
    .when('/', {
        templateUrl: 'views/request.html',
		controller: 'RequestPageController',

    })
    
    .when('/view', {
        templateUrl: 'views/view.html',
		controller: 'ViewPageController',

    })

    .when('/approver', {
        templateUrl: 'views/approver.html',
		controller: 'ApprovePageController',

    })
    
});

// CONTROLLERS
DBVersionTracker.controller('RequestPageController', ['$scope','$http' ,function($scope,$http) {

	

	console.log('Request Page controller working');
    var now = new Date();
    timestamp = ((now.getMonth() < 10) ? '0' : '') + (now.getMonth()+1).toString();
    timestamp += ((now.getDate() < 10) ? '0' : '') + now.getDate().toString();
    timestamp += now.getFullYear().toString().slice(2,4);
    timestamp += now.getHours().toString();
    timestamp += now.getMinutes().toString();
    timestamp += now.getSeconds().toString();
    timestamp += now.getMilliseconds().toString();
	$scope.ticket_no =  timestamp;
	

	$scope.Formdata={}
    $scope.reset = function(){
        console.log("Reset function called : ");
        $scope.Formdata = {};
        $scope.requestForm.$setPristine();
        $('#show').hide()
        $('#reset-btn').hide()
    }
	$scope.submitForm = function() {
		console.log("SUbmit form run");

		console.log($scope);
		$scope.Formdata.requestId = timestamp;
		$scope.Formdata.status = "Pending";
		$scope.Formdata.approveDate = "NA";
		$scope.Formdata.approvedBy = "NA";
		$scope.Formdata.comment = "NA";
		var temp = new Date();
		time = ((temp.getMonth() < 10) ? '0' : '') + (temp.getMonth()+1).toString();
		time += ((temp.getDate() < 10) ? '0' : '') + temp.getDate().toString();
		time += temp.getFullYear().toString();
		$scope.Formdata.requestDate = time;
		console.log($scope.Formdata);
		$http({
			  url: '/write',
		       method: "POST",
	          data: angular.toJson($scope.Formdata),
	          headers: {
	              'Content-Type': 'application/json'
	          }
	      }).then(function(response) {
	      	$scope.msg = "Data Submitted Successfully!";
	      }, 
	      function(response) {
	      	$scope.msg = "Service not Exists";
	      });
	}
	 
	
}]);

DBVersionTracker.controller('ViewPageController', ['$scope','$http', function($scope,$http) {
    
	$scope.requests=null;
	
	$http.get('/read')
		.success(function(data,status){
			//console.log(data);
			$scope.requests=data;
		})
		.error(function(data,status){
			console.log('Error ',data);
		});
	
}]);

DBVersionTracker.controller('ApprovePageController', ['$scope', function($scope) {
	
}]);



DBVersionTracker.directive('requestItem',function(){
	console.log('requestItem directive');
		return{
			templateUrl:'views/pages/requestItem.html',
			restrict:'A',
			replace:true,
	
		}
});





